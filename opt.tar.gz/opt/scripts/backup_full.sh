#!/bin/bash

# backup_full.sh - Script de backup con soporte de argumentos

show_help() {
    echo "Uso: $0 -s <origen> -d <destino>"
    echo ""
    echo "Opciones:"
    echo "  -s    Directorio de origen a backupear"
    echo "  -d    Directorio de destino donde guardar el backup"
    echo "  -help Muestra esta ayuda"
    echo ""
    echo "Ejemplo:"
    echo "  $0 -s /var/log -d /backup_dir"
}

# Sin argumentos → ayuda
if [ $# -eq 0 ]; then
    show_help
    exit 1
fi

# Parseo de argumentos
while [[ "$#" -gt 0 ]]; do
    case $1 in
        -s) ORIGEN="$2"; shift ;;
        -d) DESTINO="$2"; shift ;;
        -help) show_help; exit 0 ;;
        *) echo "Argumento desconocido: $1"; show_help; exit 1 ;;
    esac
    shift
done

# Validar que se pasaron ambos argumentos
if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
    echo "Error: debés especificar origen (-s) y destino (-d)."
    show_help
    exit 1
fi

# Validar que el origen existe y está montado
if ! mountpoint -q "$ORIGEN" && [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio de origen '$ORIGEN' no existe o no está disponible."
    exit 1
fi

# Validar que el destino existe y está montado
if ! mountpoint -q "$DESTINO" && [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio de destino '$DESTINO' no existe o no está montado."
    exit 1
fi

# Fecha en formato ANSI YYYYMMDD
FECHA=$(date +%Y%m%d)

# Nombre del directorio de origen (ej: /var/log → log)
NOMBRE=$(basename "$ORIGEN")

# Nombre del archivo de backup
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

# Ejecutar backup
echo "Iniciando backup de '$ORIGEN' en '$DESTINO/$ARCHIVO'..."
tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

if [ $? -eq 0 ]; then
    echo "Backup completado exitosamente: $DESTINO/$ARCHIVO"
else
    echo "Error durante el backup."
    exit 1
fi
