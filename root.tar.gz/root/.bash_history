history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname "TPServer"
hostnamectl
vi /etc/hosts
apt update
ip a
which ssh
apt upgrade
apt update
cat /etc/apt/sources.list
telnet localhost 22
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
apt upgrade
cat /etc/apt/sources.list
vi /etc/apt/sources.list
apt full-upgrade
cat /etc/os-release 
init 6
cat /etc/os-release 
apt update
apt upgrade
apt full-upgrade
init 6
php -l /var/www/html/index.php
tail -f /var/log/apache2/error.log
apt install php-mysqli -y
systemctl restart apache2
php -l /var/www/html/index.php
tail -f /var/log/apache2/error.log
apt install mariadb-server -y
systemctl start mariadb
systemctl restart apache2
tail -f /var/log/apache2/error.log
cd /var/www/html/
ls
ls -l
cat index.php 
mysql -u root
systemctl restart apache2
tail -f /var/log/apache2/error.log
mysql -u root
systemctl restart apache2
tail -f /var/log/apache2/error.log
quit
exit
cat /etc/os-release 
systemctl status sshd
apt install ssh
which ssh
systemctl status sshd
telnet localhost ssh
ip a
useradd juan
passwd juan
groups juan
usermod -aG sudo juan
groups juan
apt install apache2 php libapache2-mod-php -y
systemctl status apache2
cd /var/www/html
ll
ls
ip a
ls
rm index.html 
cd ..
ls
ls -l
chmod 777 html/
lss
ls
cd html/
ls
systemctl status apache2
systemctl stop apache2
systemctl start apache2
systemctl status apache2
ls
cat index.php 
ls
ls -l
cd ..
ls
ls -l
cd html/
chown root:root index.php logo.png 
systemctl stop apache2
systemctl start apache2
systemctl status apache2
tail -f /var/log/apache2/error.log
ls
ls -l
cat index.php 
cat index.php  | grep lcar5
cat index.php  | grep lcar
vi index.php 
cd /home/
ls
ls -l
cd compartido/
ls
cd ..
cd ..
ls
ls -l
chmod 777 home
chmod 755 home
cd home/
cat db.sql 
tail /etc/passwd
cd /root
cd /home/juan
cd /home/
l
ls
cd /etc/skel
ls
ll
ls -l
whoami
shutdown now
shutdown now
lsblk
clear
fdisk /dev/sdc
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
cd /
ls
mkdir www_dir
mkdir backup_dir
lsblk
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
cd /etc/apache2/
ls
cd /var/www/
ls
cd html/
ls
cp * /www_dir/
cd /www_dir/
ls
ls -l
ll
cd /etc/apache2/
ls
ls -l
vi apache2.conf 
history | grep apache
cat apache2.conf | grep www
vi apache2.conf 
ls
cd conf-enabled/
ls
cd ../sites-enabled/
ls
vi 000-default.conf 
systemctl restart apache2
systemctl status apache2
cd /var/www/html/
ls
rm *
ls
cd /www_dir/
ls
ls -l
chmod 400 logo.png 
systemctl restart apache2
chmod 644 logo.png 
systemctl restart apache2
blkid /dev/sdc1 /dev/sdc2
lsblk
blkid /dev/sdc1 /dev/sdc2
vi /etc/fstab
init 6
vi /etc/ssh/sshd_config
cd /root
ls
cd Material_Adicional_TPVMCA/
ls
cp clave_publica.pub ..
cd ..
ls
mkdir .ssh
ls
ls -l
ls -la
mv cat clave_publica.pub 
cat clave_publica.pub 
vi .ssh/authorized_keys
cd .ssh
ls
vi authorized_keys
cd ..
ls
ls -l
chmod 700 .ssh/
chmod 600 .ssh/authorized_keys 
systemctl restart sshd
quit
exit
exit
lsblk
ls
ls /
df -h
cd /proc
ls
ls -l
cat partitions 
cd /opt
ls
mkdir /opt/scripts
cd /opt/scripts/
vi backup_full.sh
chmod 777 backup_full.sh 
ls
ls -l
ls -l /var/log/
du -sh /var/log/
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh -s /var/log -d /backup_dir
cd /backup_dir/
ls
ls -l
rm log_bkp_20260601.tar.gz 
du -sh /var/log/
crontab -e
init 6
